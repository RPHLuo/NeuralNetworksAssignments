Partners:
Robin Luo
100998216

Assignment 2
COMP4107 Neural Networks
Tony White

libraries used:
numpy
tensorflow
time
matplotlib

Note:
Some parts can take a very long time due to large epochs and extra logging.
Please comment the code out to test the other parts.
