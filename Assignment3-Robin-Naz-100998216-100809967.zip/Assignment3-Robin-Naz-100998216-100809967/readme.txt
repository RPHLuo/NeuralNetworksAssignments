Partners:
Robin Luo
100998216
Naz Al Kassm
100809967

Assignment 3
COMP4107 Neural Networks
Tony White

libraries used:
numpy
sklearn
tensorflow
matplotlib
minisom
pandas
random

We used online resources and code
